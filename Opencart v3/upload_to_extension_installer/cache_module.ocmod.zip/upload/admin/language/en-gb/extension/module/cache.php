<?php
// Heading
$_['heading_title']    = 'Cache Control';
$_['text_extension']    = 'Extensions';

// Text
$_['text_success']     = 'Success: You have successfully cleared cache';
$_['text_failure']     = 'Failure: Error clearing cache';

